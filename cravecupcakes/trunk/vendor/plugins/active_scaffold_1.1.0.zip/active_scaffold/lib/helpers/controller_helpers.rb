module ActiveScaffold
  module Helpers
    module ControllerHelpers
      include ActiveScaffold::Helpers::Ids
    end
  end
end